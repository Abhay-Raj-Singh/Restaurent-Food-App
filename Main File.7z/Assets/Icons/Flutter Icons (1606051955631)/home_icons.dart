/// flutter:
///   fonts:
///    - family:  HomeIcons
///      fonts:
///       - asset: fonts/HomeIcons.ttf
///
/// 
///
import 'package:flutter/widgets.dart';

class HomeIcons {
	HomeIcons._();

	static const _kFontFam = 'HomeIcons';

	static const IconData header = const IconData( 0xe005, fontFamily: _kFontFam, fontPackage: 'Home');
	static const IconData group_149 = const IconData( 0xe015, fontFamily: _kFontFam, fontPackage: 'Home');
}
