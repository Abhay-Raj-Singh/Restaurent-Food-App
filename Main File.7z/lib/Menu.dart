import 'package:flutter/material.dart';
import 'package:adobe_xd/pinned.dart';
import './CheckOut.dart';
import 'package:adobe_xd/page_link.dart';
import './Home.dart';
import 'package:flutter_svg/flutter_svg.dart';

class Menu extends StatelessWidget {
  Menu({
    Key key,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xffffffff),
      body: Stack(
        children: <Widget>[
          Transform.translate(
            offset: Offset(59.0, 532.0),
            child: Container(
              width: 274.0,
              height: 68.0,
              decoration: BoxDecoration(
                color: const Color(0xffff0000),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(59.0, 787.0),
            child: Container(
              width: 269.0,
              height: 68.0,
              decoration: BoxDecoration(
                color: const Color(0xffff0000),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(59.0, 1016.0),
            child: Container(
              width: 274.0,
              height: 68.0,
              decoration: BoxDecoration(
                color: const Color(0xffff0000),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(60.0, 1246.0),
            child: Container(
              width: 287.0,
              height: 68.0,
              decoration: BoxDecoration(
                color: const Color(0xffff0000),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(55.0, 300.0),
            child: Container(
              width: 269.0,
              height: 68.0,
              decoration: BoxDecoration(
                color: const Color(0xffff0000),
              ),
            ),
          ),
          // Adobe XD layer: 'HEADER' (group)
          PageLink(
            links: [
              PageLinkInfo(
                transition: LinkTransition.Fade,
                ease: Curves.easeOut,
                duration: 0.3,
                pageBuilder: () => CheckOut(),
              ),
            ],
            child: SizedBox(
              width: 375.0,
              height: 80.0,
              child: Stack(
                children: <Widget>[
                  Pinned.fromSize(
                    bounds: Rect.fromLTWH(0.0, 0.0, 375.0, 80.0),
                    size: Size(375.0, 80.0),
                    pinLeft: true,
                    pinRight: true,
                    pinTop: true,
                    pinBottom: true,
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color(0xffff0000),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0x29000000),
                            offset: Offset(0, 10),
                            blurRadius: 6,
                          ),
                        ],
                      ),
                    ),
                  ),
                  Pinned.fromSize(
                    bounds: Rect.fromLTWH(58.0, 11.0, 171.0, 40.0),
                    size: Size(375.0, 80.0),
                    pinTop: true,
                    fixedWidth: true,
                    fixedHeight: true,
                    child: Text(
                      'Food Factory',
                      style: TextStyle(
                        fontFamily: 'Bebas',
                        fontSize: 30,
                        color: const Color(0xff2e2e2e),
                      ),
                      textAlign: TextAlign.left,
                    ),
                  ),
                  Pinned.fromSize(
                    bounds: Rect.fromLTWH(324.0, 17.0, 40.0, 40.0),
                    size: Size(375.0, 80.0),
                    pinRight: true,
                    fixedWidth: true,
                    fixedHeight: true,
                    child:
                        // Adobe XD layer: 'ic_cart' (shape)
                        Container(
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: const AssetImage(''),
                          fit: BoxFit.fill,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(55.0, 148.0),
            child:
                // Adobe XD layer: 'ic_popular_food_1' (shape)
                PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => CheckOut(),
                ),
              ],
              child: Container(
                width: 272.5,
                height: 181.5,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(50.0),
                  image: DecorationImage(
                    image: const AssetImage(''),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(60.0, 384.0),
            child:
                // Adobe XD layer: 'ic_popular_food_4' (shape)
                PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => CheckOut(),
                ),
              ],
              child: Container(
                width: 272.7,
                height: 181.5,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(50.0),
                  image: DecorationImage(
                    image: const AssetImage(''),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(60.0, 868.0),
            child:
                // Adobe XD layer: 'ic_popular_food_5' (shape)
                PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => CheckOut(),
                ),
              ],
              child: Container(
                width: 272.8,
                height: 181.5,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(50.0),
                  image: DecorationImage(
                    image: const AssetImage(''),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(60.0, 1130.0),
            child:
                // Adobe XD layer: 'ic_popular_food_2' (shape)
                PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => CheckOut(),
                ),
              ],
              child: Container(
                width: 287.4,
                height: 149.5,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(50.0),
                  image: DecorationImage(
                    image: const AssetImage(''),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(60.0, 616.0),
            child:
                // Adobe XD layer: 'ic_popular_food_6' (shape)
                PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => CheckOut(),
                ),
              ],
              child: Container(
                width: 272.8,
                height: 204.6,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(50.0),
                  image: DecorationImage(
                    image: const AssetImage(''),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(106.8, 334.0),
            child: PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => CheckOut(),
                ),
              ],
              child: SizedBox(
                width: 139.0,
                child: Text(
                  'Grilled Salmon',
                  style: TextStyle(
                    fontFamily: 'SF Pro Text',
                    fontSize: 18,
                    color: const Color(0xff000000),
                  ),
                  textAlign: TextAlign.right,
                ),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(106.8, 569.0),
            child: PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => CheckOut(),
                ),
              ],
              child: SizedBox(
                width: 139.0,
                child: Text(
                  'Chicken Breast',
                  style: TextStyle(
                    fontFamily: 'SF Pro Text',
                    fontSize: 18,
                    color: const Color(0xff000000),
                  ),
                  textAlign: TextAlign.right,
                ),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(121.2, 821.0),
            child: PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => CheckOut(),
                ),
              ],
              child: SizedBox(
                width: 125.0,
                child: Text(
                  'Mutton Fried',
                  style: TextStyle(
                    fontFamily: 'SF Pro Text',
                    fontSize: 18,
                    color: const Color(0xff000000),
                  ),
                  textAlign: TextAlign.right,
                ),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(156.0, 1050.0),
            child: PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => CheckOut(),
                ),
              ],
              child: SizedBox(
                width: 54.0,
                child: Text(
                  'Garlic',
                  style: TextStyle(
                    fontFamily: 'SF Pro Text',
                    fontSize: 18,
                    color: const Color(0xff000000),
                  ),
                  textAlign: TextAlign.right,
                ),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(121.0, 1280.0),
            child: PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => CheckOut(),
                ),
              ],
              child: SizedBox(
                width: 114.0,
                child: Text(
                  'French Fries',
                  style: TextStyle(
                    fontFamily: 'SF Pro Text',
                    fontSize: 18,
                    color: const Color(0xff000000),
                  ),
                  textAlign: TextAlign.right,
                ),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(40.0, 95.0),
            child: Container(
              width: 312.0,
              height: 33.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14.0),
                color: const Color(0xffffffff),
                border: Border.all(width: 1.0, color: const Color(0xff707070)),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(52.0, 104.0),
            child: Container(
              width: 10.0,
              height: 13.0,
              decoration: BoxDecoration(
                borderRadius:
                    BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                color: const Color(0xffffffff),
                border: Border.all(width: 1.0, color: const Color(0xff707070)),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(60.5, 114.5),
            child: SvgPicture.string(
              _svg_j1w75x,
              allowDrawingOutsideViewBox: true,
            ),
          ),
          Transform.translate(
            offset: Offset(23.0, 102.0),
            child: SizedBox(
              width: 282.0,
              child: Text(
                '   Restaurant ,Cuisine , Or a Dish...….',
                style: TextStyle(
                  fontFamily: 'SF Pro Text',
                  fontSize: 15,
                  color: const Color(0xff000000),
                ),
                textAlign: TextAlign.right,
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(0.0, 11.0),
            child:
                // Adobe XD layer: 'ic_home' (shape)
                PageLink(
              links: [
                PageLinkInfo(
                  transition: LinkTransition.Fade,
                  ease: Curves.easeOut,
                  duration: 0.3,
                  pageBuilder: () => Home(),
                ),
              ],
              child: Container(
                width: 52.0,
                height: 58.0,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image: const AssetImage(''),
                    fit: BoxFit.fill,
                  ),
                ),
              ),
            ),
          ),
          Transform.translate(
            offset: Offset(0.0, 1360.0),
            child: SizedBox(
              width: 375.0,
              height: 55.0,
              child: Stack(
                children: <Widget>[
                  Pinned.fromSize(
                    bounds: Rect.fromLTWH(0.0, 0.0, 375.0, 55.0),
                    size: Size(375.0, 55.0),
                    pinLeft: true,
                    pinRight: true,
                    pinTop: true,
                    pinBottom: true,
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color(0xffffffff),
                        border: Border.all(
                            width: 1.0, color: const Color(0xff707070)),
                      ),
                    ),
                  ),
                  Pinned.fromSize(
                    bounds: Rect.fromLTWH(31.0, 19.0, 19.0, 20.0),
                    size: Size(375.0, 55.0),
                    pinLeft: true,
                    fixedWidth: true,
                    fixedHeight: true,
                    child: Container(
                      decoration: BoxDecoration(
                        color: const Color(0xff000000),
                        border: Border.all(
                            width: 1.0, color: const Color(0xff707070)),
                      ),
                    ),
                  ),
                  Pinned.fromSize(
                    bounds: Rect.fromLTWH(301.6, 10.5, 24.2, 34.8),
                    size: Size(375.0, 55.0),
                    pinRight: true,
                    pinTop: true,
                    pinBottom: true,
                    fixedWidth: true,
                    child: PageLink(
                      links: [
                        PageLinkInfo(
                          transition: LinkTransition.Fade,
                          ease: Curves.easeOut,
                          duration: 0.3,
                          pageBuilder: () => Home(),
                        ),
                      ],
                      child: SvgPicture.string(
                        _svg_o3k478,
                        allowDrawingOutsideViewBox: true,
                        fit: BoxFit.fill,
                      ),
                    ),
                  ),
                  Pinned.fromSize(
                    bounds: Rect.fromLTWH(168.0, 10.0, 42.0, 45.0),
                    size: Size(375.0, 55.0),
                    pinBottom: true,
                    fixedWidth: true,
                    fixedHeight: true,
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius:
                            BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                        color: const Color(0xffffffff),
                        border: Border.all(
                            width: 1.0, color: const Color(0xff000000)),
                      ),
                    ),
                  ),
                  Pinned.fromSize(
                    bounds: Rect.fromLTWH(175.0, 19.0, 28.0, 26.0),
                    size: Size(375.0, 55.0),
                    fixedWidth: true,
                    fixedHeight: true,
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius:
                            BorderRadius.all(Radius.elliptical(9999.0, 9999.0)),
                        color: const Color(0xff000000),
                        border: Border.all(
                            width: 1.0, color: const Color(0xff707070)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

const String _svg_j1w75x =
    '<svg viewBox="60.5 114.5 2.0 7.0" ><path transform="translate(60.5, 114.5)" d="M 0 0 L 2 7" fill="none" stroke="#707070" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
const String _svg_o3k478 =
    '<svg viewBox="301.6 904.5 24.2 34.8" ><path transform="matrix(0.034899, -0.999391, 0.999391, 0.034899, 301.59, 938.47)" d="M 16.99999618530273 0 L 34 23 L 0 23 Z" fill="#000000" stroke="#707070" stroke-width="1" stroke-miterlimit="4" stroke-linecap="butt" /></svg>';
